﻿using System;
using System.Data;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace WpfApp_пр7
{
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            

            InitializeComponent();
            
            foreach (UIElement o1 in MainRoot.Children)
            {
                if(o1 is Button)
                {
                    ((Button)o1).Click += Button_Click;
                }
            }
        }
        //ограничение на ввод
        private void textBox1_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            e.Handled = "0123456789+-*/().".IndexOf(e.Text) < 0;
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                string str = (string)((Button)e.OriginalSource).Content;
                if (str == "CE") { textLabel.Text = ""; }
                else if (str == "C") { textLabel.Text = textLabel.Text.Remove(textLabel.Text.Length - 1, 1); }

                else if (str == "=")
                {
                    textLabel.Text = new DataTable().Compute(textLabel.Text, null).ToString();
                    textLabel.Text = textLabel.Text.Replace(",", ".");

                }
                else { textLabel.Text += str; }
            }
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }
            
            
        }
    }
}
