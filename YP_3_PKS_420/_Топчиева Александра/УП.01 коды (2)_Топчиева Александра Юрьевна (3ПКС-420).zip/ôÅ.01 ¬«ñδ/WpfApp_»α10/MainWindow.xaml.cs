﻿using System;
using System.Windows;



namespace WpfApp_пр10
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, EventArgs e)
        {

            try
            {
                var xl = new Microsoft.Office.Interop.Excel.Application();
                var ln = xl.WorksheetFunction.Ln(Convert.ToDouble(tbo.Text));
                tbl.Text = Convert.ToString(ln);
                xl.Quit();
            } 
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }


        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            try
            {
                var xl = new Microsoft.Office.Interop.Excel.Application();
                var log = xl.WorksheetFunction.Log10(Convert.ToDouble(tbo.Text));
                tbl.Text = Convert.ToString(log);
                xl.Quit();
            }
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            try
            {
                var xl = new Microsoft.Office.Interop.Excel.Application();
                var cosh = xl.WorksheetFunction.Cosh(Convert.ToDouble(tbo.Text));
                tbl.Text = Convert.ToString(cosh);
                xl.Quit();
            }
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            try
            {
                var xl = new Microsoft.Office.Interop.Excel.Application();
                var sqrtpi = xl.WorksheetFunction.SqrtPi(Convert.ToDouble(tbo.Text));
                tbl.Text = Convert.ToString(sqrtpi);
                xl.Quit();
            }
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }
            
        }
        private void Button_Click_4(object sender, RoutedEventArgs e)
        {
            try
            {
                var xl = new Microsoft.Office.Interop.Excel.Application();
                var phi = xl.WorksheetFunction.Phi(Convert.ToDouble(tbo.Text));
                tbl.Text = Convert.ToString(phi);
                xl.Quit();
            }
            catch (Exception ex) //обработка исключения
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Button_Click_5(object sender, RoutedEventArgs e)
        {
            Environment.Exit(0);

        }
    
    }
}
