﻿
using System.Windows;

namespace WpfApp_пр8
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            text.SpellCheck.IsEnabled = true;
        }

        private void Button_Click2(object sender, RoutedEventArgs e)
        {
            text.Clear();
        }


    }
}
