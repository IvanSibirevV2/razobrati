﻿
using System.Collections.Generic;

using System.Windows;

using Excel = Microsoft.Office.Interop.Excel;
namespace WPF_EXCEL
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var excel = new Microsoft.Office.Interop.Excel.Application();
            List<int> nums = new List<int>();
            for(int i = 0; i < 10; i++)
            {
                int num = (int)excel.WorksheetFunction.RandBetween(1, 1_000);
                nums.Add(num);
                listbox.Items.Add(num);
            }
            sum.Content = excel.WorksheetFunction.Sum(nums.ToArray());
            avg.Content = excel.WorksheetFunction.Average(nums.ToArray());
           
            min.Content = excel.WorksheetFunction.Min(nums.ToArray());
            max.Content = excel.WorksheetFunction.Max(nums.ToArray());
          
            excel.Quit();
        }
     
    }

}
