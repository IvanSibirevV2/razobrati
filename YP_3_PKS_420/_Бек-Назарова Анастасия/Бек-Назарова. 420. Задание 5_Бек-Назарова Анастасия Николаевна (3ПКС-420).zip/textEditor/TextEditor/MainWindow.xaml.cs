﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Interop;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;

namespace TextEditor
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        

        private async void openBtn_Click(object sender, RoutedEventArgs e)
        {
            await Task.Delay(0);
            try
            {
                
                OpenFileDialog ofd = new OpenFileDialog();
                ofd.Filter = "RichText Files (*.rtf)|*.rtf|Unicode (*.txt)|*.txt|Binary (*.bin)|*.bin|Win1251 (*.docx)|*.docx|All Files (*.*)|*.*";

                if (ofd.ShowDialog() == true)
                {
                    TextRange doc = new TextRange(textEditor.Document.ContentStart, textEditor.Document.ContentEnd);
                    using (FileStream fs = new FileStream(ofd.FileName, FileMode.Open))
                    {
                        if (System.IO.Path.GetExtension(ofd.FileName).ToLower() == ".rtf")
                            doc.Load(fs, DataFormats.Rtf);

                        if (System.IO.Path.GetExtension(ofd.FileName).ToLower() == ".txt")
                            doc.Load(fs, DataFormats.Text);

                        if (System.IO.Path.GetExtension(ofd.FileName).ToLower() == ".bin")
                            doc.Load(fs, DataFormats.Text);

                        if (System.IO.Path.GetExtension(ofd.FileName).ToLower() == ".docx")
                            doc.Load(fs, DataFormats.Text);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private async void saveBtn_Click(object sender, RoutedEventArgs e)
        {
            await Task.Delay(0);
            try
            {
                SaveFileDialog sfd = new SaveFileDialog();
                sfd.Filter = "RichText Files (*.rtf)|*.rtf|Unicode (*.txt)|*.txt|Binary (*.bin)|*.bin|Win1251 (*.docx)|*.docx";
                if (sfd.ShowDialog() == true)
                {
                    TextRange doc = new TextRange(textEditor.Document.ContentStart, textEditor.Document.ContentEnd);
                    using (FileStream fs = File.Create(sfd.FileName))
                    {
                        if (System.IO.Path.GetExtension(sfd.FileName).ToLower() == ".rtf")
                            doc.Save(fs, DataFormats.Rtf);


                        if (System.IO.Path.GetExtension(sfd.FileName).ToLower() == ".docx")
                            using (StreamWriter writer = new StreamWriter(fs, Encoding.GetEncoding(1251)))
                            {
                                writer.WriteLine(doc.Text);
                            }


                        if (System.IO.Path.GetExtension(sfd.FileName).ToLower() == ".txt")
                            using (StreamWriter writer = new StreamWriter(fs, Encoding.UTF8))
                            {
                                writer.WriteLine(doc.Text);
                            }

                        if (System.IO.Path.GetExtension(sfd.FileName).ToLower() == ".bin")
                        {
                            using (BinaryWriter writer = new BinaryWriter(fs))
                            {
                                writer.Write(doc.Text);
                            }
                        }
                           
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printBtn_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                PrintDialog pd = new PrintDialog();

                if ((pd.ShowDialog() == true))
                {
                    pd.PrintVisual(textEditor as Visual, "Print Visual");
                    pd.PrintDocument((((IDocumentPaginatorSource)textEditor.Document).DocumentPaginator), "Print Document");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
