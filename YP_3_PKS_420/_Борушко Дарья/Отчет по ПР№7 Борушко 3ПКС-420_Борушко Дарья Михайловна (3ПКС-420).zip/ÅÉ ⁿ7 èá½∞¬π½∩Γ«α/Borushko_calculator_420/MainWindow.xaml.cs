﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Borushko_calculator_420
{
  
    public partial class MainWindow : Window

    {
        private string key = "";
        private string[] nums = { "", "" };
        private string number = " ";
        public MainWindow()
        {
            InitializeComponent();
            calc.Foreground = Brushes.Goldenrod;
        }
        public Dictionary<string, Func<double, double, double>> bin_operator = new Dictionary<string, Func<double, double, double>>
        {
            { "+", (x, y) => x + y },
            { "-", (x, y) => x - y },
            { "x", (x, y) => x * y },
            { "/", (x, y) => x / y },

        };
        public Dictionary<string, Func<double, double>> unar_operator = new Dictionary<string, Func<double, double>>
        {
            { "^2", x => x * x },
            { "^3", x => x * x * x },
            { "±", x => -x },
            { "√", x => Math.Sqrt(x) },
        };
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (calc.Text == "Failed")
            {
                calc.Text = "";
                for (int i = 0; i < nums.Length; i++)
                {
                    nums[i] = "";
                }
                number = "";
            }
            string button_content = ((Button)e.OriginalSource).Content.ToString();
            string old_key = key;
            if (isNum(button_content))
            {
                calc.Text += button_content;
                number += button_content;
            }
            else
            {
                if (button_content == "=" || button_content == "СE") { }
                else
                {
                    key = button_content;
                    if (isNum(nums[0]) && key == "√")
                    {
                        calc.Text = "sqrt ";
                        calc.Text += nums[0];
                        key = "sqrt";
                        number = calc.Text.Replace("sqrt ", "_");
                    }
                    else
                    {
                        if (key == "х²")
                        {
                            calc.Text += "^2";
                            number = calc.Text.Replace("^2", " ");
                        }
                        else if (key == "x³")
                        {
                            calc.Text += "^3";
                            number = calc.Text.Replace("^3", "_");
                        }

                        else if (key == "±")
                        {
                            calc.Text += "±";
                            number = calc.Text.Replace("±", "_");
                        }
                        else if (key == "√" || key == "sqrt")
                        {
                            calc.Text = "sqrt ";
                            key = "sqrt";
                            number = calc.Text.Replace("sqrt ", "_");
                        }
                        else
                        {
                            if ((button_content == "-" && calc.Text.Length == 0) || button_content == ",")
                            {
                                calc.Text += button_content;
                                number += button_content;
                            }
                            else if (button_content == "-" && number.Contains("_"))
                            {
                                calc.Text += button_content;
                                number += button_content;
                                if (old_key == "sqrt")
                                    key = old_key;
                            }
                            else
                            {
                                calc.Text += button_content;
                                number += "_";
                            }
                        }
                    }
                }
            }

            if (button_content == "СE")
            {
                calc.Text = "";
                for (int i = 0; i < nums.Length; i++)
                    nums[i] = "";
                number = "";
            }



            else if (button_content == "=")
            {
                nums = number.Split('_');
                nums = nums.Where(value => value != "").ToArray();

                string operation = "";

                if (nums.Length == 1)
                {
                    for (int i = 0; i < calc.Text.Length; i++)
                    {
                        if (calc.Text[i] == '^' && (calc.Text[i + 1] == '2' || calc.Text[i + 1] == '3'))
                        {
                            operation = calc.Text.Substring(i, 2);
                            break;
                        }
                        else if (key == "sqrt")
                        {
                            operation = "√";
                            break;
                        }
                        else if (calc.Text[i] == '!')
                        {
                            operation = calc.Text[i].ToString();
                            break;
                        }
                        else if (key == "±")
                        {
                            operation = "±";
                            break;
                        }
                    }

                    foreach (KeyValuePair<string, Func<double, double>> unar_operate in unar_operator)
                    {
                        if (unar_operate.Key == operation)
                        {

                            if (operation == "√")
                            {
                                if (double.Parse(nums[0]) < 0)
                                    calc.Text = "Failed";
                                else
                                    calc.Text = unar_operate.Value(double.Parse(nums[0])).ToString();
                            }
                            else
                                calc.Text = unar_operate.Value(double.Parse(nums[0])).ToString();
                            break;
                        }
                    }
                }
                else
                {
                    nums = nums.Where(value => value != "").ToArray();

                    for (int i = 0; i < calc.Text.Length; i++)
                    {
                        if ((calc.Text[i] == '+' || calc.Text[i] == '-' || calc.Text[i] == 'x' || calc.Text[i] == '/' || calc.Text[i] == '%') && i > 0)
                        {
                            operation = calc.Text[i].ToString();
                            break;
                        }
                    }

                    foreach (KeyValuePair<string, Func<double, double, double>> bin_operate in bin_operator)
                    {
                        if (bin_operate.Key == operation)
                        {
                            if (operation == "/")
                            {
                                if (nums[1] == "0")
                                    calc.Text = "Failed";
                                else
                                    calc.Text = bin_operate.Value(double.Parse(nums[0]), double.Parse(nums[1])).ToString();
                            }
                            else
                            {
                                calc.Text = bin_operate.Value(double.Parse(nums[0]), double.Parse(nums[1])).ToString();
                            }
                            break;
                        }
                    }
                }
                nums[0] = calc.Text;
                number = calc.Text;
            }
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            MessageBoxResult result = MessageBox.Show("Вы точно хотите выйти?", "Выход", MessageBoxButton.OKCancel);
            if (result == MessageBoxResult.Cancel)
                e.Cancel = true;
            base.OnClosing(e);
        }

        private static bool isNum(string str)
        {
            double num = 0;
            return double.TryParse(str, out num);
        }

    }
}
