﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;
using System.Reflection;

namespace up_check_orf
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
     
            var Word = new Microsoft.Office.Interop.Word.Application();
            var textIsCorrect = Word.CheckSpelling(text.Text);
            if (textIsCorrect)
            {
                MessageBoxResult result = MessageBox.Show("В тексте нет ошибок!", "Всё правильно", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            }
            else
            {
                MessageBoxResult result = MessageBox.Show("В тексте есть одна или несколько ошибок!", "Есть ошибки", MessageBoxButton.OK, MessageBoxImage.Warning);
            }
        }

	    protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;
        }
    }
}
