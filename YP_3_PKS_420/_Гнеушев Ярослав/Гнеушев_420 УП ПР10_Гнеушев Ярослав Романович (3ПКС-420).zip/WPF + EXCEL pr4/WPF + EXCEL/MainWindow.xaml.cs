﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using Excel = Microsoft.Office.Interop.Excel;
namespace WPF___EXCEL
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            var XL = new Microsoft.Office.Interop.Excel.Application();
            List<int> nums = new List<int>();
            for(int i = 0; i < 100; i++)
            {
                int num = (int)XL.WorksheetFunction.RandBetween(1, 1_000);
                nums.Add(num);
                listbox.Items.Add(num);
            }
            sum.Content = XL.WorksheetFunction.Sum(nums.ToArray());
            avg.Content = XL.WorksheetFunction.Average(nums.ToArray());
            mode.Content = XL.WorksheetFunction.Mode(nums.ToArray());
            min.Content = XL.WorksheetFunction.Min(nums.ToArray());
            max.Content = XL.WorksheetFunction.Max(nums.ToArray());
            disp.Content = Math.Round(XL.WorksheetFunction.Var(nums.ToArray()),2);
            XL.Quit();
        }
        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;
        }
    }

}
