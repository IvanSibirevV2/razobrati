﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Word = Microsoft.Office.Interop.Word;

namespace WORD_TABLE_pr3
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            var Word = new Microsoft.Office.Interop.Word.Application();
            var doc = new Microsoft.Office.Interop.Word.Document();
            object objMissing = System.Reflection.Missing.Value;
            object endOfDoc = "\\endofdoc";
            Word.Visible = true;
            doc = Word.Documents.Add(ref objMissing, ref objMissing, ref objMissing, ref objMissing);
            int rows = new Random().Next(1, 11);
            int cols = new Random().Next(1, 11);
            Microsoft.Office.Interop.Word.Table table;
            Microsoft.Office.Interop.Word.Range rangeOfWord = doc.Bookmarks.get_Item(ref endOfDoc).Range;
            table = doc.Tables.Add(rangeOfWord, rows, cols, objMissing, objMissing);
            table.Range.ParagraphFormat.SpaceAfter = 8;
            for (int i = 1; i <= rows; i++)
            {
                for (int j = 1; j <= cols; j++)
                {
                    table.Cell(i, j).Range.Text = $"Строка {i}, Столбец {j}";
                }
            }
            try
            {
                table.Borders.Shadow = true;

            }
            catch (Exception) { }
            Word.Quit();
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;
        }
    }
}
