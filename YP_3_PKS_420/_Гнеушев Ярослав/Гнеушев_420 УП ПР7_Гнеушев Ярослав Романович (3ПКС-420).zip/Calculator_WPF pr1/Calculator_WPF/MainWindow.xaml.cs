﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
namespace Calculator_WPF
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void Button0_Click(object sender, RoutedEventArgs e)
        {
            var txt = (e.Source as Button).Content.ToString();
            if (new string[9] {"1", "2", "3", "4", "5", "6", "7", "8", "9" }.Contains(txt))
            {
                screen.Text += txt;
            }
            else if (txt == "0")
            {
                if (screen.Text.Length != 0)
                {
                    screen.Text += "0";

                }
            }
            else if(new string[4] { "+", "-", "*", "/" }.Contains(txt) && !new char[5] { '+', '-', '*', '/', '.' }.Contains(screen.Text[screen.Text.Length - 1]))
            {
                screen.Text += txt;
            }
            else if(txt == ".")
            {
                if (screen.Text.Length == 0 || !new char[5] { '+', '-', '*', '/', '.' }.Contains(screen.Text[screen.Text.Length - 1]))
                    if (screen.Text.Count(x => x == '.') < screen.Text.Count(x => x == '+' || x == '-' || x == '*' || x == '/') + 1)
                        screen.Text += ".";
            }
            else if(txt == "CA")
            {
                screen.Text = "";
            }
            else if(txt == "=" && screen.Text.Trim().Length > 0)
            {
                try
                {
                    screen.Text = Eval(screen.Text).ToString().Replace(',', '.');
                }
                catch (OverflowException)
                {
                    MessageBox.Show("Переполнение!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (DivideByZeroException)
                {
                    MessageBox.Show("Деление на ноль!", "Ошибка!", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                catch (Exception)
                {
                    MessageBox.Show("Ошибка в выражении!");
                }
            }
            else if(txt == "DEL")
            {
                if (screen.Text.Length > 0)
                    screen.Text = screen.Text.Substring(0, screen.Text.Length - 1);
            }
        }

        static Double Eval(String expression)
        {
            System.Data.DataTable table = new System.Data.DataTable();
            return Convert.ToDouble(table.Compute(expression, String.Empty));
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;
        }

    }
}
