﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.IO;
using System.Drawing.Printing;
using System.Drawing;

namespace up_encoding
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const string BASE_DIR = @"C:\Users\gneus\Desktop";
        public MainWindow()
        {
            InitializeComponent();
        }
        string StringFromRichTextBox(RichTextBox rtb)
        {
           return new TextRange(rtb.Document.ContentStart, rtb.Document.ContentEnd).Text;
        }
        private void Button_Click_win1251(object sender, RoutedEventArgs e)
        {
            string file = BASE_DIR+@"\test_win1251.txt";
            string msg = StringFromRichTextBox(text_to_save);
            string[] str = { msg };
            File.WriteAllLines(file, str, Encoding.GetEncoding(1251));
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_bin(object sender, RoutedEventArgs e)
        {
            string msg = StringFromRichTextBox(text_to_save);
            string fileName = BASE_DIR + @"\test_bin.bin";
            using (BinaryWriter writer = new BinaryWriter(File.Open(fileName, FileMode.OpenOrCreate)))
            {
                writer.Write(msg);
            }
            MessageBox.Show("Успешно!");
        }
    

        private void Button_Click_Uni(object sender, RoutedEventArgs e)
        {
            UnicodeEncoding unicode = new UnicodeEncoding();
            String unicodeString = StringFromRichTextBox(text_to_save);
            Byte[] encodedBytes = unicode.GetBytes(unicodeString);
            String decodedString = unicode.GetString(encodedBytes);

            using (StreamWriter writer = new StreamWriter(BASE_DIR + @"\test_uni.txt", false, Encoding.UTF8))
            {
                writer.WriteLine(decodedString);
            }
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_RTF(object sender, RoutedEventArgs e)
        {
            
            TextRange text = new TextRange(text_to_save.Document.ContentStart, text_to_save.Document.ContentEnd);
            string fileName = BASE_DIR + @"\test_rtf.rtf";
            using (FileStream fs = File.Open(fileName, FileMode.OpenOrCreate))
            {
                text.Save(fs, DataFormats.Rtf);
            }
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_RTF_Read(object sender, RoutedEventArgs e)
        {
            // suppose that we have a test.txt at E:\
            string filePath = BASE_DIR + @"\test_rtf.rtf";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Файл не найден!\nУбедитесь, что сохранили его");
                return;
            }
            string rtf = File.ReadAllText(filePath);
            using (MemoryStream stream = new MemoryStream(Encoding.Default.GetBytes(rtf)))
            {
                text_to_save.Selection.Load(stream, DataFormats.Rtf);
            }
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_bin_Read(object sender, RoutedEventArgs e)
        {
            string filePath = BASE_DIR + @"\test_bin.bin";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Файл не найден!\nУбедитесь, что сохранили его");
                return;
            }
            var text = File.ReadAllText(filePath);
            text_to_save.Selection.Text = text;
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_win1251_Read(object sender, RoutedEventArgs e)
        {
            string filePath = BASE_DIR + @"\test_win1251.txt";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Файл не найден!\nУбедитесь, что сохранили его");
                return;
            }
            var text = File.ReadAllText(filePath, Encoding.GetEncoding("windows-1251"));
            text_to_save.Selection.Text = text;
            MessageBox.Show("Успешно!");
        }

        private void Button_Click_Uni_Read(object sender, RoutedEventArgs e)
        {
            string filePath = BASE_DIR + @"\test_uni.txt";
            if (!File.Exists(filePath))
            {
                MessageBox.Show("Файл не найден!\nУбедитесь, что сохранили его");
                return;
            }
            var text = File.ReadAllText(filePath);
            text_to_save.Selection.Text = text;
            MessageBox.Show("Успешно!");
        }

        protected override void OnClosing(System.ComponentModel.CancelEventArgs e)
        {
            e.Cancel = MessageBox.Show("Вы действительно хотите выйти?", "Подтвердите действие", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.No;
        }

        private void Button_Click_Print(object sender, RoutedEventArgs e)
        {
            string s = text_to_save.Selection.Text;

            PrintDocument p = new PrintDocument();
            p.PrintPage += delegate (object sender1, PrintPageEventArgs e1)
            {
                e1.Graphics.DrawString(s, new Font("Times New Roman", 12), new SolidBrush(System.Drawing.Color.Black), new RectangleF(0, 0, p.DefaultPageSettings.PrintableArea.Width, p.DefaultPageSettings.PrintableArea.Height));

            };
            try
            {
                p.Print();
            }
            catch (Exception ex)
            {
                throw new Exception("Проверьте подключение к принтеру", ex);
            }
        }
    }
}
